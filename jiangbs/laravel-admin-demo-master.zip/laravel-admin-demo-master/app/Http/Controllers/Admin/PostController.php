<?php

namespace App\Http\Controllers\Admin;

class UserController extends BaseController
{
}
