<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        LARAVEL-ADMIN
    </div>
    <!-- Default to the left -->
    <strong>Copyright © 2015 <a href="https://github.com/liyu001989">liyu001989</a>.</strong> All rights reserved.
</footer>
